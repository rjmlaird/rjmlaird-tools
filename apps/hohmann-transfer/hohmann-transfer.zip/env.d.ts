import type { Env } from "./src/env";

declare module "cloudflare:test" {
  // Gives SELF/env the Worker's bindings type in tests.
  interface ProvidedEnv extends Env {}
}
